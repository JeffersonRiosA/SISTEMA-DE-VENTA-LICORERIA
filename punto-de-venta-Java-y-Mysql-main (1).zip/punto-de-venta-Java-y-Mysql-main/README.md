# punto-de-venta-Java-y-Mysql
Panel de Administración
![Sin título](https://user-images.githubusercontent.com/88554898/128564032-48ff58d6-7a11-418c-9d86-f559cd0c11a3.png)
